location.href = 'https://lastpass.com/vault/'
