document.documentElement.setAttribute('data-extension-enabled', 'mv3')
