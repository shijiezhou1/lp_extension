document.documentElement.setAttribute('data-extension-platform', 'safari')
